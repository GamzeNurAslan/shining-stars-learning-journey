# Kargo ETL Studio 🚚

CSV'den gelen kargo gönderilerini güvenilir biçimde işleyen, hatalı kayıtları kaybetmeden ayıran ve temiz veriyi PostgreSQL'e idempotent olarak yükleyen uçtan uca bir veri mühendisliği projesi.

**Hazırlayan:** Gamze Nur Aslan

## Projenin amacı

Bu proje yalnızca CSV'yi veritabanına yazmaz. Kaynak veriyi korur, tekrarları tespit eder, alanları standartlaştırır, satır seviyesinde hata nedeni üretir, kalite kurallarını çalıştırır ve aynı yükleme tekrarlandığında kayıtları çoğaltmaz.

```text
CSV / Faker
    ↓
Bronze: ham veri
    ↓
Transform: normalize + type conversion
    ├── Silver: 4.903 temiz kayıt
    ├── Quarantine: 97 geçersiz kayıt
    └── Duplicate audit: 50 tekrar kaydı
    ↓
Quality checks
    ↓
PostgreSQL: primary key + upsert
```

## Yönergeye karşılık gelen adımlar

| Adım | Uygulama |
|---|---|
| 1. Veritabanını ayağa kaldır | `docker-compose.yml` ile PostgreSQL |
| 2. Kaynak veri üret | `scripts/generate_data.py`, Faker `tr_TR`, seed |
| 3. Keşfet | `scripts/explore_data.py` |
| 4. Temizle | `src/kargo_etl/cleaning.py`, karantina ve duplicate audit |
| 5. Veritabanına yaz | `src/kargo_etl/db.py`, SQLAlchemy |
| 6. Hatayı üret ve gör | `scripts/duplicate_demo.py` |
| 7. Idempotent yap | `ON CONFLICT (gonderi_id) DO UPDATE` |
| 8. Kalite kontrolü | `src/kargo_etl/quality.py` ve opsiyonel GX expectation batch |
| 9-10. Airflow / dynamic task mapping | `dags/kargo_pipeline.py` ile isteğe bağlı |

## Veri sonucu

`data/raw/gonderiler.csv` dosyasındaki doğrulanmış sonuç:

- 5.050 ham satır
- 50 tekrar eden `gonderi_id`
- 97 geçersiz kayıt
- 4.903 temiz kayıt

Burada 50 duplicate kayıt ayrı bir denetim çıktısıdır. 97 kayıt ise duplicate'ler tekilleştirildikten sonra ana akışa alınmayan geçersiz kayıtlardır. Böylece kayıtların neden elendiği görünür kalır.

## Hızlı başlangıç

### Docker ile önerilen çalıştırma

```bash
docker compose up --build
```

Tarayıcıdan `http://localhost:8501` adresini açın.

### Yerel Python ile

```bash
python -m venv .venv
# Windows PowerShell
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python scripts/run_etl.py
python scripts/verify_pipeline.py
.\.venv\Scripts\python.exe -m streamlit run app.py --server.address 127.0.0.1 --server.port 8501
```

Kurulum tamamlandıktan sonra Windows PowerShell'de `.\start-local.ps1` komutuyla da başlatabilirsiniz. Site adresi `http://localhost:8501`'dir. Docker kullanılacaksa yerel Streamlit sürecini kapatıp `docker compose up --build` çalıştırın; iki yöntemi aynı anda 8501 portunda başlatmayın.

PostgreSQL bağlantısı için `.env.example` dosyasını `.env` olarak kopyalayın. PostgreSQL yoksa ETL ve kalite kontrolü yine çalışır; yalnızca veritabanına yükleme adımı için PostgreSQL gerekir.

## Arayüz

Streamlit uygulaması tek ana arayüzdür ve şu sekmeleri içerir:

- **Genel Bakış:** ham, temiz, karantina ve duplicate sayıları
- **Kalite:** kural bazında PASS/FAIL sonuçları
- **Karantina:** hata kodlarıyla filtrelenebilen kayıtlar
- **Analiz:** durum ve şube dağılımları
- **Veri:** temiz veri önizlemesi ve CSV indirme

İlk 25 satır ekranda gösterilir; tam veri indirme düğmeleri tüm kayıtları verir.

## Komutlar

```bash
# Kontrollü örnek veri üret
python scripts/generate_data.py --output data/raw/gonderiler_faker.csv

# Kaynak veriyi keşfet
python scripts/explore_data.py --input data/raw/gonderiler.csv

# ETL çalıştır
python scripts/run_etl.py --input data/raw/gonderiler.csv

# Kalite raporunu üret
python scripts/quality_check.py --input data/raw/gonderiler.csv

# 4.903 / 4.903 ve idempotency kanıtını doğrula
python scripts/verify_pipeline.py --input data/raw/gonderiler.csv

# PostgreSQL'e upsert
python scripts/load_postgres.py --input data/raw/gonderiler.csv

# Primary key duplicate hatasını bilerek göster
python scripts/duplicate_demo.py --input data/raw/gonderiler.csv
```

## Adım adım çalışma dosyaları

Klasörün kökündeki `generate_data.py`, `kesfet.py`, `temizle.py`, `yukle.py`, `hata_uret.py`, `idempotent_yukle.py` ve `kalite_kontrol.py` dosyaları, ders adımlarını tek tek göstermek için korunmuştur. Tekrar kullanılabilir çekirdek mantık ise `src/kargo_etl/` altında toplanmış, dashboard ve doğrulama scriptleri bu çekirdeği kullanacak şekilde düzenlenmiştir.

## Kalite kuralları

Temiz veri şu koşulları sağlamalıdır:

1. Zorunlu kolonlar mevcut olmalı.
2. `gonderi_id` boş olmamalı ve benzersiz olmalı.
3. `sube_kodu`, `alici_sehir`, `agirlik_kg` ve `kabul_tarihi` boş olmamalı.
4. Ağırlık sayısal ve sıfırdan büyük olmalı.
5. Durum, tanımlı durum kümesinde olmalı: `kabul`, `yolda`, `dagitimda`, `teslim`, `iade`.
6. Teslim tarihi kabul tarihinden önce olmamalı.

Şehirler Türkçe karakter ve büyük/küçük harf farklarına göre normalize edilir. Örneğin `istanbul`, `ISTANBUL` ve ` İstanbul ` aynı standart değere dönüşür.

Pipeline kapısı hızlı ve deterministik Python kontrollerini kullanır. `great-expectations` kurulu olduğunda `scripts/quality_check.py` aynı temiz batch'i ayrıca GX expectation'ları ile doğrular ve `gx_report.json` üretir. Böylece arayüzdeki kalite sonucu ile standart expectation raporu birbirine karıştırılmaz.

## Neden duplicate kayıtları silmiyoruz?

Duplicate kayıtların ana akışa girmesini engelliyoruz, fakat onları tamamen yok etmiyoruz. `data/processed/duplicates.csv` içinde kaynak satır numarası ve `duplicate_record` nedeni ile saklıyoruz. Geçersiz kayıtlar ise `quarantine.csv` içinde hata kodlarıyla tutuluyor.

## Idempotency

Hedef tabloda `gonderi_id` primary key'dir. Yükleme şu davranışı kullanır:

```sql
INSERT ...
ON CONFLICT (gonderi_id)
DO UPDATE SET ...;
```

Bu nedenle aynı temiz CSV'yi iki kez yüklemek 4.903 satırı 9.806'ya çıkarmaz. Sonuç yine 4.903 satır olur.

## Karşılaşılan hata ve çözümü

İlk tasarımda `pandas.to_sql(..., if_exists="replace")` primary key oluşturmadığı için `ON CONFLICT` güvenilir değildi. Bu sürümde tablo şeması SQLAlchemy ile açıkça oluşturulur ve `gonderi_id` primary key olarak tanımlanır.

Bir diğer hata, Docker içinden `localhost` kullanılmasıdır. Container içindeki `localhost` uygulamanın kendisini ifade eder. Compose ağı içinde PostgreSQL host'u `postgres`, bilgisayardan bağlantıda ise `localhost` kullanılır. Bu ayrım `DATABASE_URL` ile yönetilir.

## Airflow seçeneği

`dags/kargo_pipeline.py` günlük ETL akışını `extract → transform → validate → load` görevlerine ayırır. Airflow zorunlu olmadığı için temel Docker Compose'a eklenmedi; dosya Airflow ortamına kopyalanarak ayrıca çalıştırılabilir. DAG içinde iki çıktı için dynamic task mapping örneği de bulunur.

## Production notu

Bu proje eğitim ve lokal demo için tasarlanmıştır. Gerçek üretimde secret manager, migration aracı, merkezi loglama, alarm/SLO, erişim kontrolü, veri sözleşmesi ve kalıcı artifact storage eklenmelidir.

## Sunum için 45 saniyelik anlatım 🎓

> Kargo ETL Studio, CSV'deki gönderi verisini bronze, silver ve quarantine katmanlarından geçirir. Önce ham veriyi koruyup duplicate kayıtları denetim çıktısına ayırdım. Sonra şehir, ağırlık, durum ve tarih alanlarını normalize ettim; hatalı kayıtları nedenleriyle birlikte karantinaya aldım. 5.050 ham kayıttan 50 duplicate ve 97 geçersiz kayıt ayrıldı, 4.903 temiz kayıt kaldı. Temiz veriyi kalite kurallarından geçirdikten sonra `gonderi_id` primary key ve `ON CONFLICT DO UPDATE` ile PostgreSQL'e yüklüyorum. Böylece aynı pipeline tekrar çalışsa bile veri çoğalmıyor; bu özelliğe idempotency deniyor.
