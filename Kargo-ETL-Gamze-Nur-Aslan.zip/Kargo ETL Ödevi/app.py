from __future__ import annotations

import json
from pathlib import Path

import pandas as pd
import streamlit as st

from src.kargo_etl.pipeline import run_pipeline
from src.kargo_etl.quality import quality_summary, validate_clean_data

ROOT = Path(__file__).parent
RAW_PATH = ROOT / "data" / "raw" / "gonderiler.csv"
OUT_DIR = ROOT / "data" / "processed"

st.set_page_config(page_title="Kargo ETL Studio | Gamze Nur Aslan", page_icon="📦", layout="wide", initial_sidebar_state="collapsed")
st.markdown("""
<style>
.block-container {padding-top: 1.7rem; padding-bottom: 2rem; max-width: 1180px;}
[data-testid="stMetricValue"] {font-size: 1.9rem; color: #243b53;}
.hero {padding: .2rem 0 1rem; border-bottom: 1px solid #d9dee5; margin-bottom: 1.25rem;}
.hero h1 {margin: 0; color: #1f2933; font-size: 2rem; letter-spacing: -.02em;}
.hero p {margin: .35rem 0 0; color: #627d98; font-size: .95rem;}
[data-testid="stMetric"] {background: #ffffff; border: 1px solid #e1e7ed; border-radius: 8px; padding: .7rem .8rem;}
[data-testid="stMetricLabel"] {color: #627d98;}
[data-testid="stMetricDelta"] {font-size: .76rem;}
.run-note {background: #eef4f8; border-left: 4px solid #e4573d; border-radius: 6px; padding: .65rem .85rem; color: #486581; margin: .9rem 0 1.2rem;}
[data-testid="stAppDeployButton"], .stDeployButton {display: none;}
@media (max-width: 640px) {
  .block-container {padding: 1rem .85rem 1.5rem;}
  .hero h1 {font-size: 1.55rem;}
  .hero p {font-size: .85rem;}
  [data-testid="stMetric"] {padding: .55rem .6rem;}
  [data-testid="stMetricValue"] {font-size: 1.45rem;}
  [data-testid="stHorizontalBlock"] {gap: .45rem;}
  [data-testid="stHorizontalBlock"] > div {min-width: calc(50% - .25rem) !important; flex: 1 1 calc(50% - .25rem) !important;}
}
</style>
""", unsafe_allow_html=True)

st.markdown('<div class="hero"><h1>Kargo ETL Studio</h1><p>Gamze Nur Aslan · Gönderi verisini inceleme, temizleme ve yükleme ekranı</p></div>', unsafe_allow_html=True)

with st.sidebar:
    st.header("Veri işlemleri")
    uploaded = st.file_uploader("CSV dosyası seçin", type=["csv"])
    run_clicked = st.button("Veriyi işle", type="primary", use_container_width=True)
    st.caption("Dosya seçilmezse örnek veri kullanılır.")
    st.divider()
    st.caption("Kullanım")
    st.markdown("1. CSV dosyasını seçin  \n2. Veriyi işleyin  \n3. Sonuçları sekmelerden inceleyin")

input_path = RAW_PATH
if uploaded is not None:
    temporary = OUT_DIR / "uploaded.csv"
    temporary.parent.mkdir(parents=True, exist_ok=True)
    temporary.write_bytes(uploaded.getvalue())
    input_path = temporary

if run_clicked or not (OUT_DIR / "manifest.json").exists():
    with st.spinner("ETL ve kalite kontrolleri çalışıyor..."):
        result = run_pipeline(input_path, OUT_DIR)
    st.success(f"Veri işlendi. Çalışma kodu: {result.run_id}")

manifest_path = OUT_DIR / "manifest.json"
if not manifest_path.exists():
    st.info("Başlamak için soldan Pipeline'ı çalıştır düğmesine basın.")
    st.stop()

manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
clean = pd.read_csv(OUT_DIR / "clean.csv")
quarantine = pd.read_csv(OUT_DIR / "quarantine.csv")
duplicates = pd.read_csv(OUT_DIR / "duplicates.csv")
quality = json.loads((OUT_DIR / "quality_report.json").read_text(encoding="utf-8"))

metric_cols = st.columns(5)
metric_cols[0].metric("Gelen", f"{manifest['input_rows']:,}")
metric_cols[1].metric("Temiz", f"{manifest['clean_rows']:,}")
metric_cols[2].metric("Karantina", f"{manifest['quarantine_rows']:,}")
metric_cols[3].metric("Tekrar", f"{manifest['duplicate_rows']:,}")
metric_cols[4].metric("Kalite", quality["status"], delta=f"{quality['passed']}/{quality['total']} geçti")
st.caption(f"Son çalışma: {manifest['run_id']} · Kaynak: {Path(manifest['source']).name}")

tab_overview, tab_quality, tab_quarantine, tab_analysis, tab_data = st.tabs(["Özet", "Kalite kontrolü", "Karantina", "Dağılım", "Temiz veri"])

with tab_overview:
    st.subheader("Kayıtların durumu")
    clean_rate = manifest["clean_rows"] / manifest["input_rows"] if manifest["input_rows"] else 0
    st.markdown(f'<div class="run-note"><strong>İşleme özeti:</strong> Gelen kayıtların %{clean_rate * 100:.1f} kadarı temiz akışa alındı. Tekrar kayıtlar ve kuralları geçemeyen satırlar ayrı çıktılarda saklandı.</div>', unsafe_allow_html=True)
    result_left, result_right = st.columns([1.1, .9])
    with result_left:
        st.markdown("**Temiz akış oranı**")
        st.progress(clean_rate)
        st.caption(f"{manifest['clean_rows']:,} / {manifest['input_rows']:,} kayıt temiz akışa alındı.")
    with result_right:
        st.markdown("**Ana akıştan ayrılanlar**")
        rejected = pd.DataFrame({"Kayıt türü": ["Tekrar", "Karantina"], "Adet": [manifest["duplicate_rows"], manifest["quarantine_rows"]]})
        st.dataframe(rejected, use_container_width=True, hide_index=True)
    st.subheader("Temiz verinin durumu")
    st.bar_chart(clean["durum"].value_counts(), color="#e4573d")
    st.caption("Temiz veri, tekilleştirme ve kalite kontrollerinden sonra PostgreSQL'e yüklenmeye hazırdır.")

with tab_quality:
    st.subheader("Kontrol sonuçları")
    quality_df = pd.DataFrame(quality["checks"])
    st.dataframe(quality_df, use_container_width=True, hide_index=True)
    if quality["status"] == "PASS":
        st.success("Temiz veri bütün kontrollerden geçti.")
    else:
        st.error("En az bir kalite kuralı başarısız.")

with tab_quarantine:
    st.subheader("İncelenmesi gereken kayıtlar")
    if quarantine.empty:
        st.success("Karantinada kayıt yok.")
    else:
        selected = st.multiselect("Hata kodu", sorted({code for value in quarantine["hata_kodlari"].fillna("") for code in str(value).split(";") if code}), default=[])
        view = quarantine
        if selected:
            view = quarantine[quarantine["hata_kodlari"].apply(lambda x: any(code in str(x).split(";") for code in selected))]
        st.caption(f"Gösterilen: {len(view):,} kayıt · Toplam karantina: {len(quarantine):,}")
        st.dataframe(view.head(200), use_container_width=True, hide_index=True)
        st.download_button("Karantina CSV'sini indir", quarantine.to_csv(index=False).encode("utf-8"), "quarantine.csv", "text/csv")

with tab_analysis:
    left, right = st.columns(2)
    with left:
        st.subheader("Durum")
        st.bar_chart(clean["durum"].value_counts())
    with right:
        st.subheader("Şube")
        st.bar_chart(clean["sube_kodu"].value_counts())

with tab_data:
    st.subheader("Temiz veri önizlemesi")
    st.caption(f"Toplam {len(clean):,} kayıt. Burada ilk 25 satır gösteriliyor.")
    st.dataframe(clean.head(25), use_container_width=True, hide_index=True)
    st.download_button("Temiz veriyi indir", clean.to_csv(index=False).encode("utf-8"), "clean.csv", "text/csv")
    st.download_button("Duplicate audit'i indir", duplicates.to_csv(index=False).encode("utf-8"), "duplicates.csv", "text/csv")
