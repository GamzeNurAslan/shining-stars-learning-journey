"""Airflow 2/3 uyumlu, isteğe bağlı orkestrasyon örneği."""

from datetime import datetime
from pathlib import Path

import pandas as pd
from airflow.decorators import dag, task

from src.kargo_etl.db import load_to_postgres
from src.kargo_etl.pipeline import run_pipeline


@dag(
    dag_id="kargo_etl_studio",
    schedule="0 7 * * *",
    start_date=datetime(2026, 1, 1),
    catchup=False,
    tags=["etl", "kargo", "quality"],
)
def kargo_etl_studio():
    @task
    def transform() -> str:
        result = run_pipeline("/opt/airflow/data/raw/gonderiler.csv", "/opt/airflow/data/processed")
        return result.output_dir

    @task
    def validate(output_dir: str) -> str:
        report = Path(output_dir) / "quality_report.json"
        data = report.read_text(encoding="utf-8")
        if '"status": "PASS"' not in data:
            raise ValueError("Kalite kontrolü başarısız")
        return output_dir

    @task
    def load(output_dir: str) -> int:
        clean = pd.read_csv(Path(output_dir) / "clean.csv", parse_dates=["kabul_tarihi", "teslim_tarihi"])
        return load_to_postgres(clean)

    @task
    def publish_artifact(kind: str, output_dir: str) -> str:
        return str(Path(output_dir) / f"{kind}.csv")

    output_dir = transform()
    validated = validate(output_dir)
    load(validated)
    publish_artifact.partial(output_dir=validated).expand(kind=["clean", "quarantine"])


kargo_etl_studio()
