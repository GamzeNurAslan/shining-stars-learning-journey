from __future__ import annotations

import argparse
from pathlib import Path
import sys

import pandas as pd
from sqlalchemy import text
from sqlalchemy.exc import IntegrityError

sys.path.insert(0, str(Path(__file__).parents[1]))

from src.kargo_etl.db import get_engine, load_to_postgres
from src.kargo_etl.pipeline import run_pipeline

parser = argparse.ArgumentParser(description="Primary key duplicate hatasını bilerek üret")
parser.add_argument("--input", default="data/raw/gonderiler.csv")
parser.add_argument("--output-dir", default="data/processed")
args = parser.parse_args()
run_pipeline(args.input, args.output_dir)
clean = pd.read_csv(Path(args.output_dir) / "clean.csv", parse_dates=["kabul_tarihi", "teslim_tarihi"])
load_to_postgres(clean)
row = clean.iloc[0].to_dict()
try:
    engine = get_engine()
    with engine.begin() as connection:
        connection.execute(text("INSERT INTO gonderiler (gonderi_id, sube_kodu, alici_sehir, agirlik_kg, durum, kabul_tarihi, teslim_tarihi, kaynak_satir_no, etl_run_id) VALUES (:gonderi_id, :sube_kodu, :alici_sehir, :agirlik_kg, :durum, :kabul_tarihi, :teslim_tarihi, :kaynak_satir_no, :etl_run_id)"), row)
except IntegrityError:
    print("EXPECTED ERROR: duplicate gonderi_id primary key tarafından engellendi.")
else:
    raise SystemExit("Beklenen duplicate hatası oluşmadı.")
