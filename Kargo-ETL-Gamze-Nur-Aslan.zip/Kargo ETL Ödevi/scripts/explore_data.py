from __future__ import annotations

import argparse
from pathlib import Path
import sys

import pandas as pd

sys.path.insert(0, str(Path(__file__).parents[1]))

parser = argparse.ArgumentParser(description="Kaynak veriyi keşfet")
parser.add_argument("--input", default="data/raw/gonderiler.csv")
args = parser.parse_args()
df = pd.read_csv(args.input, encoding="utf-8")
print(f"Satır: {len(df):,}")
print(f"Kolonlar: {', '.join(df.columns)}")
print("\nEksik değerler:")
print(df.isna().sum().to_string())
print("\nVeri tipleri:")
print(df.dtypes.to_string())
print("\nDurum dağılımı:")
print(df["durum"].value_counts(dropna=False).to_string())
print("\nDuplicate gonderi_id:", int(df["gonderi_id"].duplicated().sum()))
