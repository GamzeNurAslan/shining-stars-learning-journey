from __future__ import annotations

import argparse
from pathlib import Path
import sys

import pandas as pd
from sqlalchemy import func, select

from src.kargo_etl.db import get_engine, get_table, load_to_postgres
from src.kargo_etl.pipeline import run_pipeline
from sqlalchemy import MetaData

sys.path.insert(0, str(Path(__file__).parents[1]))

parser = argparse.ArgumentParser(description="Aynı veriyi iki kez upsert ederek idempotency göster")
parser.add_argument("--input", default="data/raw/gonderiler.csv")
parser.add_argument("--output-dir", default="data/processed")
args = parser.parse_args()
run_pipeline(args.input, args.output_dir)
clean = pd.read_csv(Path(args.output_dir) / "clean.csv", parse_dates=["kabul_tarihi", "teslim_tarihi"])
first = load_to_postgres(clean)
second = load_to_postgres(clean)
print(f"İlk yükleme: {first:,}")
print(f"İkinci yükleme: {second:,}")
assert first == second == len(clean)
print("IDEMPOTENCY PASS")
