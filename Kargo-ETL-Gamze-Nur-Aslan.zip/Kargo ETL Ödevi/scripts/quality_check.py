from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

import pandas as pd

sys.path.insert(0, str(Path(__file__).parents[1]))

from src.kargo_etl.pipeline import run_pipeline

parser = argparse.ArgumentParser(description="Kargo kalite kontrolü")
parser.add_argument("--input", default="data/raw/gonderiler.csv")
parser.add_argument("--output-dir", default="data/processed")
args = parser.parse_args()
result = run_pipeline(args.input, args.output_dir)
report = json.loads((Path(args.output_dir) / "quality_report.json").read_text(encoding="utf-8"))
for check in report["checks"]:
    print(f"[{check['status']}] {check['rule']}: actual={check['actual']} expected={check['expected']}")
print(f"\nQUALITY {report['status']} ({report['passed']}/{report['total']})")
try:
    from src.kargo_etl.gx_quality import run_gx_validation

    clean = pd.read_csv(Path(args.output_dir) / "clean.csv")
    gx_report = run_gx_validation(clean)
    (Path(args.output_dir) / "gx_report.json").write_text(json.dumps(gx_report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(f"GREAT EXPECTATIONS {gx_report['status']} ({len(gx_report['results'])} expectations)")
except ImportError:
    print("GREAT EXPECTATIONS SKIPPED: paket kurulu değil; temel kalite kapısı yine çalıştı.")
except Exception as exc:
    print(f"GREAT EXPECTATIONS WARNING: çalıştırılamadı ({type(exc).__name__}); temel kalite kapısı yine çalıştı.")
