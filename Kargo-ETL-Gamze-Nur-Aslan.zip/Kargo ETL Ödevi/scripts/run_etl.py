from __future__ import annotations

import argparse
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parents[1]))

from src.kargo_etl.pipeline import run_pipeline

parser = argparse.ArgumentParser(description="Kargo ETL pipeline")
parser.add_argument("--input", default="data/raw/gonderiler.csv")
parser.add_argument("--output-dir", default="data/processed")
args = parser.parse_args()
result = run_pipeline(args.input, args.output_dir)
print(result)
