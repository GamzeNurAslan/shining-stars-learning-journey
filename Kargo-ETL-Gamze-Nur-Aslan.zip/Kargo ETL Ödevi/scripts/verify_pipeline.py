from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

import pandas as pd

sys.path.insert(0, str(Path(__file__).parents[1]))

from src.kargo_etl.pipeline import run_pipeline

parser = argparse.ArgumentParser(description="Teslim öncesi doğrulama")
parser.add_argument("--input", default="data/raw/gonderiler.csv")
parser.add_argument("--output-dir", default="data/processed")
args = parser.parse_args()

result = run_pipeline(args.input, args.output_dir, run_id="verify")
assert result.input_rows == 5050, result
assert result.duplicate_rows == 50, result
assert result.quarantine_rows == 97, result
assert result.clean_rows == 4903, result
assert result.quality_status == "PASS", result
clean = pd.read_csv(Path(args.output_dir) / "clean.csv")
assert clean["gonderi_id"].is_unique
assert (clean["agirlik_kg"] > 0).all()
print("VERIFY PASS")
print(f"5050 ham -> 50 duplicate + 97 karantina + 4903 temiz")
