"""Kargo ETL Studio core package."""

from .pipeline import run_pipeline

__all__ = ["run_pipeline"]

