from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

import pandas as pd

REQUIRED_COLUMNS = [
    "gonderi_id",
    "sube_kodu",
    "alici_sehir",
    "agirlik_kg",
    "durum",
    "kabul_tarihi",
    "teslim_tarihi",
]

VALID_STATUSES = {"kabul", "yolda", "dagitimda", "teslim", "iade"}

CITY_LABELS = {
    "adana": "Adana",
    "ankara": "Ankara",
    "antalya": "Antalya",
    "bursa": "Bursa",
    "diyarbakir": "Diyarbakır",
    "denizli": "Denizli",
    "eskisehir": "Eskişehir",
    "gaziantep": "Gaziantep",
    "istanbul": "İstanbul",
    "izmir": "İzmir",
    "kayseri": "Kayseri",
    "konya": "Konya",
    "mersin": "Mersin",
    "samsun": "Samsun",
    "trabzon": "Trabzon",
}


@dataclass(frozen=True)
class CleanResult:
    clean: pd.DataFrame
    quarantine: pd.DataFrame
    duplicates: pd.DataFrame


def _fold_turkish(value: object) -> str | pd.NA:
    if pd.isna(value):
        return pd.NA
    text = str(value).strip()
    if not text:
        return pd.NA
    translation = str.maketrans({"İ": "i", "I": "ı", "Ş": "ş", "Ğ": "ğ", "Ü": "ü", "Ö": "ö", "Ç": "ç"})
    return text.translate(translation).casefold()


def normalize_city(value: object) -> object:
    folded = _fold_turkish(value)
    if pd.isna(folded):
        return pd.NA
    ascii_folded = (
        str(folded)
        .replace("ı", "i")
        .replace("ş", "s")
        .replace("ğ", "g")
        .replace("ü", "u")
        .replace("ö", "o")
        .replace("ç", "c")
    )
    return CITY_LABELS.get(ascii_folded, str(value).strip().title())


def _reason_frame(df: pd.DataFrame) -> pd.DataFrame:
    reasons = pd.DataFrame(index=df.index)
    reasons["gonderi_id_eksik"] = df["gonderi_id"].isna() | df["gonderi_id"].eq("")
    reasons["sube_kodu_eksik"] = df["sube_kodu"].isna() | df["sube_kodu"].eq("")
    reasons["alici_sehir_eksik"] = df["alici_sehir"].isna()
    reasons["agirlik_eksik"] = df["agirlik_kg"].isna()
    reasons["agirlik_gecersiz"] = df["agirlik_kg"].notna() & (df["agirlik_kg"] <= 0)
    reasons["durum_gecersiz"] = ~df["durum"].isin(VALID_STATUSES)
    reasons["kabul_tarihi_gecersiz"] = df["kabul_tarihi"].isna()
    reasons["teslim_tarihi_gecersiz"] = df["teslim_tarihi"].notna() & (df["teslim_tarihi"] < df["kabul_tarihi"])
    reasons["teslim_tarihi_eksik"] = df["durum"].eq("teslim") & df["teslim_tarihi"].isna()
    return reasons


def clean_data(raw: pd.DataFrame, run_id: str = "local") -> CleanResult:
    missing = [column for column in REQUIRED_COLUMNS if column not in raw.columns]
    if missing:
        raise ValueError(f"Eksik zorunlu kolonlar: {', '.join(missing)}")

    working = raw[REQUIRED_COLUMNS].copy()
    working.insert(0, "kaynak_satir_no", range(2, len(working) + 2))
    working["etl_run_id"] = run_id

    for column in ["gonderi_id", "sube_kodu", "durum"]:
        working[column] = working[column].fillna("").astype(str).str.strip()
    working["sube_kodu"] = working["sube_kodu"].str.upper()
    # Durum değerleri ASCII kodlardan oluştuğu için casefold, Türkçe "I/İ"
    # dönüşümünü şehir normalizasyonundaki kadar özel ele almamalıdır.
    working["durum"] = working["durum"].str.casefold()
    working["alici_sehir"] = working["alici_sehir"].map(normalize_city)
    working["agirlik_kg"] = pd.to_numeric(working["agirlik_kg"], errors="coerce")
    working["kabul_tarihi"] = pd.to_datetime(working["kabul_tarihi"], errors="coerce")
    working["teslim_tarihi"] = pd.to_datetime(working["teslim_tarihi"], errors="coerce")

    duplicate_mask = working.duplicated("gonderi_id", keep="first") & working["gonderi_id"].ne("")
    duplicates = working.loc[duplicate_mask].copy()
    duplicates["hata_kodlari"] = "duplicate_record"
    duplicates["hata_sayisi"] = 1

    working = working.loc[~duplicate_mask].copy()
    reasons = _reason_frame(working)
    working["hata_kodlari"] = reasons.apply(lambda row: ";".join(row.index[row].tolist()), axis=1)
    working["hata_sayisi"] = reasons.sum(axis=1).astype(int)

    quarantine = working.loc[working["hata_sayisi"].gt(0)].copy()
    clean = working.loc[working["hata_sayisi"].eq(0)].copy()
    return CleanResult(clean=clean.reset_index(drop=True), quarantine=quarantine.reset_index(drop=True), duplicates=duplicates.reset_index(drop=True))
