from __future__ import annotations

import os
from typing import Iterable

import pandas as pd
from sqlalchemy import Column, DateTime, Float, Integer, MetaData, String, Table, create_engine, func, select
from sqlalchemy.dialects.postgresql import insert


TARGET_COLUMNS = ["gonderi_id", "sube_kodu", "alici_sehir", "agirlik_kg", "durum", "kabul_tarihi", "teslim_tarihi", "kaynak_satir_no", "etl_run_id"]


def get_engine():
    url = os.getenv("DATABASE_URL", "postgresql+psycopg2://kargo_user:kargo123@localhost:5432/kargo_db")
    return create_engine(url, pool_pre_ping=True)


def get_table(metadata: MetaData) -> Table:
    return Table(
        "gonderiler", metadata,
        Column("gonderi_id", String(32), primary_key=True),
        Column("sube_kodu", String(16), nullable=False),
        Column("alici_sehir", String(64), nullable=False),
        Column("agirlik_kg", Float, nullable=False),
        Column("durum", String(16), nullable=False),
        Column("kabul_tarihi", DateTime, nullable=False),
        Column("teslim_tarihi", DateTime, nullable=True),
        Column("kaynak_satir_no", Integer, nullable=False),
        Column("etl_run_id", String(32), nullable=False),
    )


def load_to_postgres(df: pd.DataFrame) -> int:
    missing = [column for column in TARGET_COLUMNS if column not in df.columns]
    if missing:
        raise ValueError(f"Yükleme için eksik kolonlar: {', '.join(missing)}")
    engine = get_engine()
    metadata = MetaData()
    table = get_table(metadata)
    rows = df[TARGET_COLUMNS].copy().where(pd.notna(df), None).to_dict(orient="records")
    with engine.begin() as connection:
        metadata.create_all(connection)
        if rows:
            statement = insert(table).values(rows)
            update_columns = {column: getattr(statement.excluded, column) for column in TARGET_COLUMNS if column != "gonderi_id"}
            connection.execute(statement.on_conflict_do_update(index_elements=["gonderi_id"], set_=update_columns))
        count = connection.execute(select(func.count()).select_from(table)).scalar_one()
    engine.dispose()
    return int(count)

