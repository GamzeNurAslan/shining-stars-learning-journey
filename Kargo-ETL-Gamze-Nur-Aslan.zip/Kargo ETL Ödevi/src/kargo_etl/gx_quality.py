"""Great Expectations adapter for the cleaned pandas batch."""

from __future__ import annotations

from typing import Any

import pandas as pd

from .cleaning import VALID_STATUSES


def run_gx_validation(df: pd.DataFrame) -> dict[str, Any]:
    import great_expectations as gx

    context = gx.get_context(mode="ephemeral")
    data_source = context.data_sources.add_pandas(name="kargo_pandas")
    data_asset = data_source.add_dataframe_asset(name="clean_data")
    batch_definition = data_asset.add_batch_definition_whole_dataframe("whole_dataframe")
    batch = batch_definition.get_batch(batch_parameters={"dataframe": df})
    expectations = [
        gx.expectations.ExpectTableRowCountToBeBetween(min_value=len(df), max_value=len(df)),
        gx.expectations.ExpectColumnValuesToNotBeNull(column="gonderi_id"),
        gx.expectations.ExpectColumnValuesToBeUnique(column="gonderi_id"),
        gx.expectations.ExpectColumnValuesToBeBetween(column="agirlik_kg", min_value=0, strict_min=True),
        gx.expectations.ExpectColumnValuesToBeInSet(column="durum", value_set=sorted(VALID_STATUSES)),
    ]
    results = []
    for expectation in expectations:
        validation = batch.validate(expectation)
        results.append({"expectation": expectation.type, "success": bool(validation.success), "result": dict(validation.result)})
    return {"provider": "Great Expectations", "status": "PASS" if all(item["success"] for item in results) else "FAIL", "results": results}

