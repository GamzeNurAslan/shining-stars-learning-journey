from __future__ import annotations

import json
import time
import uuid
from dataclasses import asdict, dataclass
from pathlib import Path

import pandas as pd

from .cleaning import CleanResult, clean_data
from .quality import quality_summary, validate_clean_data


@dataclass(frozen=True)
class PipelineResult:
    run_id: str
    input_rows: int
    duplicate_rows: int
    quarantine_rows: int
    clean_rows: int
    quality_status: str
    output_dir: str
    duration_seconds: float


def _write_csv(df: pd.DataFrame, path: Path) -> None:
    df.to_csv(path, index=False, encoding="utf-8")


def run_pipeline(input_path: str | Path, output_dir: str | Path = "data/processed", run_id: str | None = None) -> PipelineResult:
    started = time.perf_counter()
    run_id = run_id or uuid.uuid4().hex[:12]
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    raw = pd.read_csv(input_path, encoding="utf-8")
    result: CleanResult = clean_data(raw, run_id=run_id)
    quality = quality_summary(validate_clean_data(result.clean))

    _write_csv(result.clean, output / "clean.csv")
    _write_csv(result.quarantine, output / "quarantine.csv")
    _write_csv(result.duplicates, output / "duplicates.csv")
    (output / "quality_report.json").write_text(json.dumps(quality, ensure_ascii=False, indent=2, default=str), encoding="utf-8")

    manifest = {
        "run_id": run_id,
        "source": str(input_path),
        "input_rows": len(raw),
        "duplicate_rows": len(result.duplicates),
        "quarantine_rows": len(result.quarantine),
        "clean_rows": len(result.clean),
        "quality": quality,
    }
    (output / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    return PipelineResult(run_id, len(raw), len(result.duplicates), len(result.quarantine), len(result.clean), quality["status"], str(output), time.perf_counter() - started)

