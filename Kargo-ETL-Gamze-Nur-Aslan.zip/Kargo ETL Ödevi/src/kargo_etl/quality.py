from __future__ import annotations

from typing import Any

import pandas as pd

from .cleaning import REQUIRED_COLUMNS, VALID_STATUSES


def _check(name: str, passed: bool, expected: Any, actual: Any) -> dict[str, Any]:
    return {"rule": name, "status": "PASS" if passed else "FAIL", "expected": expected, "actual": actual}


def validate_clean_data(df: pd.DataFrame) -> list[dict[str, Any]]:
    results: list[dict[str, Any]] = []
    results.append(_check("zorunlu_kolonlar", set(REQUIRED_COLUMNS).issubset(df.columns), "tüm kolonlar mevcut", list(df.columns)))
    results.append(_check("satır_sayısı", len(df) > 0, "> 0", len(df)))
    results.append(_check("gonderi_id_null", df["gonderi_id"].notna().all() if "gonderi_id" in df else False, "0 null", int(df["gonderi_id"].isna().sum()) if "gonderi_id" in df else None))
    results.append(_check("gonderi_id_unique", df["gonderi_id"].is_unique if "gonderi_id" in df else False, "benzersiz", int(df["gonderi_id"].duplicated().sum()) if "gonderi_id" in df else None))
    results.append(_check("zorunlu_değerler", all(df[column].notna().all() for column in ["sube_kodu", "alici_sehir", "agirlik_kg", "kabul_tarihi"]), "0 eksik", int(df[["sube_kodu", "alici_sehir", "agirlik_kg", "kabul_tarihi"]].isna().sum().sum()) if set(["sube_kodu", "alici_sehir", "agirlik_kg", "kabul_tarihi"]).issubset(df.columns) else None))
    results.append(_check("pozitif_ağırlık", bool((df["agirlik_kg"] > 0).all()) if "agirlik_kg" in df else False, "> 0", int((df["agirlik_kg"] <= 0).sum()) if "agirlik_kg" in df else None))
    results.append(_check("geçerli_durum", bool(df["durum"].isin(VALID_STATUSES).all()) if "durum" in df else False, sorted(VALID_STATUSES), sorted(set(df["durum"].dropna())) if "durum" in df else None))
    if {"kabul_tarihi", "teslim_tarihi"}.issubset(df.columns):
        invalid_order = (df["teslim_tarihi"].notna() & (df["teslim_tarihi"] < df["kabul_tarihi"])).sum()
    else:
        invalid_order = None
    results.append(_check("tarih_sırası", invalid_order == 0, "teslim >= kabul", int(invalid_order) if invalid_order is not None else None))
    if "hata_sayisi" in df.columns:
        results.append(_check("hata_kodu_yok", bool((df["hata_sayisi"] == 0).all()), "0 hata", int((df["hata_sayisi"] > 0).sum())))
    return results


def quality_summary(results: list[dict[str, Any]]) -> dict[str, Any]:
    passed = all(item["status"] == "PASS" for item in results)
    return {"status": "PASS" if passed else "FAIL", "passed": sum(item["status"] == "PASS" for item in results), "total": len(results), "checks": results}

