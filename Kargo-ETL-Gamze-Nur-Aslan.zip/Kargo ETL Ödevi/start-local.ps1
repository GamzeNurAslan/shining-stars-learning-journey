$ErrorActionPreference = "Stop"
$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$pythonPath = Join-Path $projectRoot ".venv\Scripts\python.exe"

if (-not (Test-Path -LiteralPath $pythonPath)) {
    Write-Error "Sanal ortam bulunamadı. Önce python -m venv .venv --system-site-packages çalıştırın."
}

Set-Location $projectRoot
& $pythonPath -m streamlit run app.py --server.address 127.0.0.1 --server.port 8501
