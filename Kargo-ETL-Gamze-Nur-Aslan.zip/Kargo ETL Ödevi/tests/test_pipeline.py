from pathlib import Path
from tempfile import TemporaryDirectory

import pandas as pd

from src.kargo_etl.cleaning import clean_data
from src.kargo_etl.pipeline import run_pipeline
from src.kargo_etl.quality import quality_summary, validate_clean_data


ROOT = Path(__file__).parents[1]


def test_expected_counts():
    raw = pd.read_csv(ROOT / "data" / "raw" / "gonderiler.csv")
    result = clean_data(raw, run_id="test")
    assert len(raw) == 5050
    assert len(result.duplicates) == 50
    assert len(result.quarantine) == 97
    assert len(result.clean) == 4903


def test_clean_data_is_valid():
    raw = pd.read_csv(ROOT / "data" / "raw" / "gonderiler.csv")
    result = clean_data(raw, run_id="test")
    summary = quality_summary(validate_clean_data(result.clean))
    assert summary["status"] == "PASS"
    assert result.clean["gonderi_id"].is_unique
    assert (result.clean["agirlik_kg"] > 0).all()


def test_pipeline_writes_manifest():
    with TemporaryDirectory(dir=ROOT) as temporary_dir:
        output_dir = Path(temporary_dir)
        result = run_pipeline(ROOT / "data" / "raw" / "gonderiler.csv", output_dir, run_id="test")
        assert result.quality_status == "PASS"
        assert (output_dir / "manifest.json").exists()
        assert (output_dir / "quality_report.json").exists()
